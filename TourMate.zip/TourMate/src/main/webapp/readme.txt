Data Soure Explorer 에 db추가
svn -> svnrepository 추가

1. pom.xml 
 -> dependency 추가
 -> 1.6버전을 1.8버전으로 수정
 -> repository 추가(위에서 10번째 줄 정도, properties 위에)
  
2. web.xml
 -> 3.1 버전으로 수정 후 프로젝트 오른쪽 클릭 -> properties -> Project Facets에서 3.1, 1.8로 버전 수정
 -> root-context 를 appServlet으로 이동 후 applicationContext로 수정 후 context-param의 value 경로 수정
 -> servlet-mapping에 url-pattern *.do라고 매핑
 -> Encoding-UTF-8추가
 
 3. src/main/resources
  -> properties, sqls 라는 folder 생성
  -> db.properties 생성
 
 4. WEB-INF/spring
  -> sqls 폴더 생성
  -> sqls밑에 mybatis-config xml 생성
  
 5. applicationContext
  -> 작성
  
 6. LogFilter
  -> pom.xml 추가
  -> web.xml LogFilter 추가
  -> paramvalue 추가
  -> appServlet에 aop-context추가(String beanconfigure file)
  -> web.xml에 aop-context 경로 추가(param-value)
  -> LogAop, LogFilter java파일 생성
  -> src/main.resources/log4j.xml 수정
 
 7. transaction 처리
  -> applicationContext 추가(namespace에 aop와 tx체크)