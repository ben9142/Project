package com.hk.tourmate.match.dto;

import java.util.Date;

public class MessageBoxDto {
	private int mseq;
	private String id;
	private String separation;
	private String send_id;
	private String country;
	private String city;
	private String sdate;
	private String ldate;
	private Date receive_date;
	private int invite_group;
	
	public MessageBoxDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MessageBoxDto(int mseq, String id, String separation, String send_id, String country, String city,
			String sdate, String ldate, Date receive_date, int invite_group) {
		super();
		this.mseq = mseq;
		this.id = id;
		this.separation = separation;
		this.send_id = send_id;
		this.country = country;
		this.city = city;
		this.sdate = sdate;
		this.ldate = ldate;
		this.receive_date = receive_date;
		this.invite_group = invite_group;
	}

	public int getMseq() {
		return mseq;
	}

	public void setMseq(int mseq) {
		this.mseq = mseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSeparation() {
		return separation;
	}

	public void setSeparation(String separation) {
		this.separation = separation;
	}

	public String getSend_id() {
		return send_id;
	}

	public void setSend_id(String send_id) {
		this.send_id = send_id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getLdate() {
		return ldate;
	}

	public void setLdate(String ldate) {
		this.ldate = ldate;
	}

	public Date getReceive_date() {
		return receive_date;
	}

	public void setReceive_date(Date receive_date) {
		this.receive_date = receive_date;
	}

	public int getInvite_group() {
		return invite_group;
	}

	public void setInvite_group(int invite_group) {
		this.invite_group = invite_group;
	}

	@Override
	public String toString() {
		return "MessageBoxDto [mseq=" + mseq + ", id=" + id + ", separation=" + separation + ", send_id=" + send_id
				+ ", country=" + country + ", city=" + city + ", sdate=" + sdate + ", ldate=" + ldate
				+ ", receive_date=" + receive_date + ", invite_group=" + invite_group + "]";
	}
	
}
