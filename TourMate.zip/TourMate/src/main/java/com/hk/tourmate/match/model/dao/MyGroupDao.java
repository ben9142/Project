package com.hk.tourmate.match.model.dao;

import java.util.List;

import com.hk.tourmate.group.dto.GroupDto;

public interface MyGroupDao {
	
	public List<GroupDto> myGroupList(String id);
	public int insertMyGroup(String id);
	public List<String> changeLeaderList(String id, int gseq);
}
