package com.hk.tourmate.group.model.dao;

import java.util.List;

import com.hk.tourmate.group.dto.TalkBoardDto;

public interface TalkBoardDao {

	public int insertTalk(TalkBoardDto tdto);
	public List<TalkBoardDto> talkList(int gseq);
}
