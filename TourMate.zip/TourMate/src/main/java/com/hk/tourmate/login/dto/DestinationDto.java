package com.hk.tourmate.login.dto;

public class DestinationDto {

	String id;
	String country;
	String city;
	String sdate;
	String ldate;
	
	public DestinationDto() {
		// TODO Auto-generated constructor stub
	}
	
	public DestinationDto(String id, String country, String city, String sdate, String ldate) {
		super();
		this.id = id;
		this.country = country;
		this.city = city;
		this.sdate = sdate;
		this.ldate = ldate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getLdate() {
		return ldate;
	}

	public void setLdate(String ldate) {
		this.ldate = ldate;
	}

	@Override
	public String toString() {
		return "DestinationDto [id=" + id + ", country=" + country + ", city=" + city + ", sdate=" + sdate + ", ldate="
				+ ldate + "]";
	}
}
