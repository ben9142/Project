package com.hk.tourmate.group.dto;

import org.springframework.web.multipart.MultipartFile;

public class RecommendationDto {
	
	private int rseq;
	private String country;
	private String city;
	private MultipartFile file;
	private String img;
	
	public RecommendationDto() {
		// TODO Auto-generated constructor stub
	}

	public RecommendationDto(int rseq, String country, String city, String img) {
		super();
		this.rseq = rseq;
		this.country = country;
		this.city = city;
		this.img = img;
	}

	public int getRseq() {
		return rseq;
	}

	public void setRseq(int rseq) {
		this.rseq = rseq;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}
	
}
