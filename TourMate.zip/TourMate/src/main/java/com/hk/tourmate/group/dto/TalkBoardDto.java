package com.hk.tourmate.group.dto;

import java.util.Date;

import com.hk.tourmate.login.dto.MemberDto;

public class TalkBoardDto {

	int tseq;
	String id;
	int gseq;
	String content;
	Date regdate;
	private MemberDto memberDto;
	
	public TalkBoardDto() {
		// TODO Auto-generated constructor stub
	}

	public TalkBoardDto(int tseq, String id, int gseq, String content, Date regdate) {
		super();
		this.tseq = tseq;
		this.id = id;
		this.gseq = gseq;
		this.content = content;
		this.regdate = regdate;
	}
	
	public TalkBoardDto(int tseq, String id, int gseq, String content, Date regdate, MemberDto memberDto) {
		super();
		this.tseq = tseq;
		this.id = id;
		this.gseq = gseq;
		this.content = content;
		this.regdate = regdate;
		this.memberDto = memberDto;
	}

	public int getTseq() {
		return tseq;
	}

	public void setTseq(int tseq) {
		this.tseq = tseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getGseq() {
		return gseq;
	}

	public void setGseq(int gseq) {
		this.gseq = gseq;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public MemberDto getMemberDto() {
		return memberDto;
	}

	public void setMemberdto(MemberDto memberDto) {
		this.memberDto = memberDto;
	}

	@Override
	public String toString() {
		return "TalkBoardDto [tseq=" + tseq + ", id=" + id + ", gseq=" + gseq + ", content=" + content + ", regdate="
				+ regdate + "]";
	}
}
