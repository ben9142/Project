package com.hk.tourmate.match.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MyGroupDto;
import com.hk.tourmate.match.model.dao.MyGroupDao;

@Service
public class MyGroupServiceImpl implements MyGroupService{
	
	@Autowired
		private MyGroupDao mygroupDao;

	@Override
	public List<GroupDto> myGroupList(String id) {
		// TODO Auto-generated method stub
		return mygroupDao.myGroupList(id);
	}

	@Override
	public int insertMyGroup(String id) {
		return mygroupDao.insertMyGroup(id);
	}

	@Override
	public List<String> changeLeaderList(String id, int gseq) {
		// TODO Auto-generated method stub
		return mygroupDao.changeLeaderList(id, gseq);
	}

}
