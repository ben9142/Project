package com.hk.tourmate.match.dto;

public class TourDiaryDto {
	private int dseq;
	private String id;
	private String country;
	private String content;
	private String sdate;
	private String ldate;
	private String mdate;
	
	public TourDiaryDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TourDiaryDto(int dseq, String id, String country, String content, String sdate, String ldate, String mdate) {
		super();
		this.dseq = dseq;
		this.id = id;
		this.country = country;
		this.content = content;
		this.sdate = sdate;
		this.ldate = ldate;
		this.mdate = mdate;
	}

	public int getDseq() {
		return dseq;
	}

	public void setDseq(int dseq) {
		this.dseq = dseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getLdate() {
		return ldate;
	}

	public void setLdate(String ldate) {
		this.ldate = ldate;
	}

	public String getMdate() {
		return mdate;
	}

	public void setMdate(String mdate) {
		this.mdate = mdate;
	}

	@Override
	public String toString() {
		return "TourDiaryDto [dseq=" + dseq + ", id=" + id + ", country=" + country + ", content=" + content
				+ ", sdate=" + sdate + ", ldate=" + ldate + ", mdate=" + mdate + "]";
	}

}