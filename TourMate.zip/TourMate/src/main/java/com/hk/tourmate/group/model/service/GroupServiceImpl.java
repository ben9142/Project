package com.hk.tourmate.group.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.group.model.dao.GroupDao;
import com.hk.tourmate.match.dto.MyGroupDto;

@Service
public class GroupServiceImpl implements GroupService{
	
	@Autowired
	private GroupDao groupdao;
	
	@Override
	public int insertGroup(GroupDto gdto){
	
		return groupdao.insertGroup(gdto);
	}

	@Override
	public GroupDto groupJoin(int gseq) {
		// TODO Auto-generated method stub
		return groupdao.groupJoin(gseq);
	}

	@Override
	public int updateGroup(GroupDto gdto) {
		return groupdao.updateGroup(gdto);
	}
	
	@Override
	public int leavegroup(String id, int gseq) {
		// TODO Auto-generated method stub
		return groupdao.leavegroup(id, gseq);
	}

	@Override
	public int changeLeader(String id, int gseq) {
		// TODO Auto-generated method stub
		return groupdao.changeLeader(id, gseq);
	}

	@Override
	public int delGroup(int gseq) {
		// TODO Auto-generated method stub
		return groupdao.delGroup(gseq);
	}

	@Override
	public int scheduleCount(Map<String, String> map) {
		// TODO Auto-generated method stub
		return groupdao.scheduleCount(map);
	}

	@Override
	public List<String> myGroupMember(int gseq) {
		// TODO Auto-generated method stub
		return groupdao.myGroupMember(gseq);
	}

	@Override
	public int changeSchedule(GroupDto gdto) {
		// TODO Auto-generated method stub
		return groupdao.changeSchedule(gdto);
	}

}
