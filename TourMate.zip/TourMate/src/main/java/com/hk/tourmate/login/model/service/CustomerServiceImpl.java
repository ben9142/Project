package com.hk.tourmate.login.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.login.dto.CustomerDto;
import com.hk.tourmate.login.model.dao.CustomerDao;

@Service
public class CustomerServiceImpl implements CustomerService{

//	@Autowired
//	private CustomerDao customerDao;
//	@Override
//	public List<CustomerDto> selectAll() {
//		// TODO Auto-generated method stub
//		return customerDao.selectAll();
//	}

	
}
