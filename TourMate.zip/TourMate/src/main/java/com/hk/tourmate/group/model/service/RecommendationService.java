package com.hk.tourmate.group.model.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.RecommendationDto;

public interface RecommendationService {
	
	public List<RecommendationDto> selectAll();
	public int insertRecommendation(RecommendationDto recDto);
	public int delRecommendation(int rseq);
	public RecommendationDto detailRecommendation(int rseq);
	public int updateRecommendation(RecommendationDto recDto);
	public List<RecommendationDto> recommendRList(String country, String city);
}
