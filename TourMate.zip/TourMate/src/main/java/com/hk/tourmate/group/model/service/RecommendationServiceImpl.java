package com.hk.tourmate.group.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.RecommendationDto;
import com.hk.tourmate.group.model.dao.RecommendationDao;
import com.hk.tourmate.login.dto.CustomerDto;

@Service
public class RecommendationServiceImpl implements RecommendationService {
	
	@Autowired
	private RecommendationDao recommendationDao;

	@Override
	public List<RecommendationDto> selectAll() {
		return recommendationDao.recommendationList();
	}

	@Override
	public int insertRecommendation(RecommendationDto recDto) {
		// TODO Auto-generated method stub
		return recommendationDao.insertRecommendation(recDto);
	}

	@Override
	public int delRecommendation(int rseq) {
		// TODO Auto-generated method stub
		return recommendationDao.delRecommendation(rseq);
	}

	@Override
	public RecommendationDto detailRecommendation(int rseq) {
		// TODO Auto-generated method stub
		return recommendationDao.detailRecommendation(rseq);
	}

	@Override
	public int updateRecommendation(RecommendationDto recDto) {
		// TODO Auto-generated method stub
		return recommendationDao.updateRecommendation(recDto);
	}

	@Override
	public List<RecommendationDto> recommendRList(String country, String city) {
		// TODO Auto-generated method stub
		return recommendationDao.recommendRList(country, city);
	}


}
