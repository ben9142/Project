package com.hk.tourmate.login.model.service;

import java.util.List;

import com.hk.tourmate.login.dto.CustomerDto;

public interface CustomerService {

//	public List<CustomerDto> selectAll();
}
