package com.hk.tourmate.match.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.match.dto.MessageBoxDto;

@Repository
public class MessageBoxDaoImpl implements MessageBoxDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public int messageRejection(int mseq) {
		int res = 0;
		res = sqlSession.delete("tourmate.messageRejection", mseq);
		
		return res;
	}

	@Override
	public int inviteMessageAccept(String id, int invite_group) {
		int res = 0;
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", id);
		map.put("invite_group", String.valueOf(invite_group));
		
		res = sqlSession.insert("tourmate.inviteMessageAccept", map);
		
		return res;
	}

	@Override
	public int requestMessageAccept(String send_id, int invite_group) {
		int res = 0;
		Map<String, String> map = new HashMap<String, String>();
		map.put("send_id", send_id);
		map.put("invite_group", String.valueOf(invite_group));
		
		res = sqlSession.insert("tourmate.requestMessageAccept", map);
		return res;
	}

	@Override
	public List<MessageBoxDto> messageList(String id, int pageNum) {
		// TODO Auto-generated method stub
		List<MessageBoxDto> list = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("pageNum", String.valueOf(pageNum));
		list = sqlSession.selectList("tourmate.messageList", map);
		
		return list;
	}

	@Override
	public int getMessageCnt(String id) {
		int res = 0;
		res = sqlSession.selectOne("tourmate.getMessageCnt", id);
		return res;
	}


}
