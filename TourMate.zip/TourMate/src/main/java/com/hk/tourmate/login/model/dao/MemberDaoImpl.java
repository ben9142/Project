package com.hk.tourmate.login.model.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.login.dto.MemberDto;

@Repository
public class MemberDaoImpl implements MemberDao{
	
	@Autowired
	private SqlSession sqlsession;

	@Override
	public int insertMember(MemberDto mdto) {
		int res = 0;
		
		res = sqlsession.insert("tourmate.insertMember", mdto);
		
		return res;
	}

	@Override
	public MemberDto loginChk(Map<String, String> map) {
		
		MemberDto mdto = sqlsession.selectOne("tourmate.loginChk", map);
		
		return mdto;
	}

	@Override
	public String checkId(String id) {
		
		String res = "";
		
		res = sqlsession.selectOne("tourmate.checkId", id);
		
		return res;
	}

	@Override
	public MemberDto myInfo(String id) {
		
		MemberDto mdto = sqlsession.selectOne("tourmate.myInfo", id);
		
		return mdto;
	}

	@Override
	public int deleteInfo(String id) {
		int res = 0;
		
		res = sqlsession.update("tourmate.deleteInfo", id);
		
		return res;
	}

	@Override
	public int updateInfo(MemberDto mdto) {
		int res = 0;
		
		res = sqlsession.update("tourmate.updateInfo", mdto);
		
		return res;
	}

	
}
