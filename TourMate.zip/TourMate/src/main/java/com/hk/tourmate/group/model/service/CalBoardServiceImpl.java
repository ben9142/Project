package com.hk.tourmate.group.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.CalBoardDto;
import com.hk.tourmate.group.model.dao.CalBoardDao;

@Service
public class CalBoardServiceImpl implements CalBoardService{

	@Autowired
	private CalBoardDao calboarddao;

	@Override
	public int insertSchedule(CalBoardDto cdto) {
		// TODO Auto-generated method stub
		return calboarddao.insertSchedule(cdto);
	}

	@Override
	public List<CalBoardDto> selectAll(Map<String, String>map) {
		// TODO Auto-generated method stub
		return calboarddao.selectAll(map);
	}

	@Override
	public int updateSchedule(CalBoardDto cdto) {
		// TODO Auto-generated method stub
		return calboarddao.updateSchedule(cdto);
	}

	@Override
	public int deleteSchedule(int gseq) {
		// TODO Auto-generated method stub
		return calboarddao.deleteSchedule(gseq);
	}
}
