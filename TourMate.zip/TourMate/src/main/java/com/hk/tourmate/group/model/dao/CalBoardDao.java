package com.hk.tourmate.group.model.dao;

import java.util.List;
import java.util.Map;

import com.hk.tourmate.group.dto.CalBoardDto;

public interface CalBoardDao {
	
	public int insertSchedule(CalBoardDto cdto);
	
	public List<CalBoardDto> selectAll(Map<String, String>map);
	
	public int updateSchedule(CalBoardDto cdto);
	
	public int deleteSchedule(int gseq);
}
