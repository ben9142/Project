package com.hk.tourmate.match.model.service;

import java.util.List;
import java.util.Map;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MatchDto;
import com.hk.tourmate.match.dto.MessageBoxDto;
public interface MatchSerivce {
	
	public MatchDto matchingList(String id);
	
	public List<MatchDto> matchDuoList(Map<String,String> map);
	
	public List<GroupDto> matchgroupList(Map<String, Object> map);
	
	public List<MatchDto> soloSerch(Map<String,String> map);
	
	public List<GroupDto> groupSerch(Map<String, String> map);
	
	public GroupDto matchGroupQseq(int gseq);
	
	public int groupMatch(Map<String, String> map);
	
	public List<String> inviteCheck(int gseq);
	
	public int inviteGroup(Map<String, String> map);
	
	public int sendMsgcheck(Map<String,String> map);
}
