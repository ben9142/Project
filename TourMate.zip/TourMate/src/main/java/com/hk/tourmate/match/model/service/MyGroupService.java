package com.hk.tourmate.match.model.service;

import java.util.List;

import com.hk.tourmate.group.dto.GroupDto;

public interface MyGroupService {

	public List<GroupDto> myGroupList(String id);
	public int insertMyGroup(String id);
	public List<String> changeLeaderList(String id, int gseq);
}
