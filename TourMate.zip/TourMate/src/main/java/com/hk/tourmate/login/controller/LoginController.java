package com.hk.tourmate.login.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.WebUtils;

import com.hk.tourmate.login.dto.DestinationDto;
import com.hk.tourmate.login.dto.MemberDto;
import com.hk.tourmate.login.model.service.DestinationService;
import com.hk.tourmate.login.model.service.MemberService;

@Controller
public class LoginController {

	@Autowired
	private MemberService memberService;
	@Autowired
	private DestinationService destinationService;

	@RequestMapping(value = "errorPage")
	public String errorPage() {

		return "common/error";
	}

	@RequestMapping(value = "loginPage")
	public String loginPage() {

		return "login/login";
	}

	@RequestMapping(value = "joinPage")
	public String joinPage() {

		return "login/infoJoin";
	}

	@RequestMapping(value = "locJoinPage")
	public String locJoinPage(HttpSession session) {

		session.getAttribute("loginPerson");

		return "login/locationJoin";
	}

	@RequestMapping(value = "insertMember", method = { RequestMethod.GET, RequestMethod.POST })
	public String insertMember(Model model, MemberDto mdto, HttpServletRequest request, BindingResult result) {

		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		MultipartFile file = mdto.getImgFile();
		String filename = "resources/img/info/" + file.getOriginalFilename();
		System.out.println("파일이름 : " + filename);
		mdto.setImg(filename);

		InputStream inputStream = null;
		OutputStream outputStream = null;

		try {
			inputStream = file.getInputStream();
			String path = WebUtils.getRealPath(request.getSession().getServletContext(), "");

			File newFile = new File(path + mdto.getImg());
			System.out.println("이미지 파일 경로 : " + newFile);

			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			outputStream = new FileOutputStream(newFile);

			int read = 0;
			byte[] b = new byte[(int) file.getSize()];

			while ((read = inputStream.read(b)) != -1) {
				outputStream.write(b, 0, read);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				outputStream.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
		String phoneNum = mdto.getPhone();
		String prePhone = phoneNum.substring(0, 3);
		String midPhone = phoneNum.substring(4, 8);
		String lasPhone = phoneNum.substring(9, 13);
		
		mdto.setPhone(prePhone + midPhone + lasPhone);
		
		String birthNum = mdto.getBirth();
		String preBirth = birthNum.substring(0, 4);
		String midBirth = birthNum.substring(5, 7);
		String lasBirth = birthNum.substring(8, 10);
		
		mdto.setBirth(preBirth + midBirth + lasBirth);
	
		try {
			int res = memberService.insertMember(mdto);
			if (res > 0) {
				model.addAttribute("id", mdto.getId());
				return "login/locationJoin";
			}else{
				return "login/login";
			}
		} catch (Exception e) {
			return "login/login";
		}		
	}

	@RequestMapping(value = "login", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Boolean> loginChk(Model model, String id, String password, HttpSession session) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", id);
		map.put("password", password);
		
		MemberDto mdto = memberService.loginChk(map);
		boolean lc = false;
		String role = "";
		boolean admin = false;

		if (mdto != null) {
			session.setAttribute("loginPerson", mdto);
			session.setMaxInactiveInterval(20*60);
			lc = true;
			role = mdto.getRole();
			System.out.println("roloroleiorjeorjor : " + role);
			if(role.equals("ADMIN")){
				admin = true;
			}
		}

		Map<String, Boolean> rmap = new HashMap<String, Boolean>();
		rmap.put("lc", lc);
		rmap.put("admin", admin);
		
		return rmap;
	}

	@RequestMapping(value = "insertDestination", method = { RequestMethod.GET, RequestMethod.POST })
	public String insertDestination(DestinationDto ddto, Model model) {

		int res = 0;

		try {
			res = destinationService.insertDestination(ddto);

			if(res > 0){
				return "login/login";
			}else{
				return "login/login";
			}
		} catch (Exception e) {
			return "login/login";
		}
	}

	@RequestMapping(value = "checkId", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Boolean> checkId(String id) {
		String res = "";

		res = memberService.checkId(id);
		boolean lc = false;
		if (res != null) {
			lc = true;
		}

		Map<String, Boolean> rMap = new HashMap<String, Boolean>();
		rMap.put("lc", lc);

		return rMap;

	}

	@RequestMapping(value = "myInfo", method = { RequestMethod.GET, RequestMethod.POST })
	public String myInfo(String id, Model model) {

		MemberDto mdto = memberService.myInfo(id);
		
		String phoneNum = mdto.getPhone();
		String prePhone = phoneNum.substring(0, 3);
		String midPhone = phoneNum.substring(3, 7);
		String lasPhone = phoneNum.substring(7, 11);
		
		mdto.setPhone(prePhone + "-" + midPhone + "-" + lasPhone);

		model.addAttribute("dto", mdto);
		return "info/myInfoR";
	}

	@RequestMapping(value = "logout", method = { RequestMethod.GET, RequestMethod.POST })
	public String logout(HttpSession session) {

		session.removeAttribute("loginPerson");

		return "login/login";
	}

	@RequestMapping(value = "updateInfoForm")
	public String updateInfoForm(String id, Model model) {

		MemberDto mdto = memberService.myInfo(id);

		if (mdto != null) {
			model.addAttribute("dto", mdto);
			return "info/myInfoU";
		}else{
			return "redirect: myInfo.do?id=" + id;
		}
	}

	@RequestMapping(value = "deleteInfo", method = { RequestMethod.GET, RequestMethod.POST })
	public String deleteInfo(HttpSession session, String id) {
		int res = 0;

		session.removeAttribute("loginPersion");

		res = memberService.deleteInfo(id);

		if (res > 0) {
			return "login/login";
		} else {
			return "redirect: myInfo.do?id=" + id;
		}
	}

	@RequestMapping(value = "updateInfo", method = { RequestMethod.GET, RequestMethod.POST })
	public String updateInfo(Model model, MemberDto mdto, HttpServletRequest request, BindingResult result) {

		MultipartFile file = mdto.getImgFile();
		String filename = "resources/img/info/" + file.getOriginalFilename();
		System.out.println("파일이름 : " + filename);
		mdto.setImg(filename);
		
		InputStream inputStream = null;
		OutputStream outputStream = null;

		try {
			inputStream = file.getInputStream();
			String path = WebUtils.getRealPath(request.getSession().getServletContext(), "");

			File newFile = new File(path + mdto.getImg());
			System.out.println("이미지 파일 경로 : " + newFile);

			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			outputStream = new FileOutputStream(newFile);

			int read = 0;
			byte[] b = new byte[(int) file.getSize()];

			while ((read = inputStream.read(b)) != -1) {
				outputStream.write(b, 0, read);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				outputStream.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
		String phoneNum = mdto.getPhone();
		String prePhone = phoneNum.substring(0, 3);
		String midPhone = phoneNum.substring(4, 8);
		String lasPhone = phoneNum.substring(9, 13);
		
		mdto.setPhone(prePhone + midPhone + lasPhone);
		
		System.out.println("아이디 : " + mdto.getId());
		int res = memberService.updateInfo(mdto);

		if (res > 0) {
			return "redirect:myInfo.do?id=" + mdto.getId();
		}

		return "redirect:myInfo.do?id=" + mdto.getId();
	}

	@RequestMapping(value = "changeLocationPage", method = { RequestMethod.GET, RequestMethod.POST })
	public String changeLocationPage(HttpSession session, Model model) {

		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		model.addAttribute("dto", mdto);

		if(mdto != null){
			return "match/changeLocation";
		}else{
			return "common/error";
		}
	}

	@RequestMapping(value = "updateDestination", method = { RequestMethod.GET, RequestMethod.POST })
	public String updateDestination(DestinationDto ddto) {
		int res = 0;
		res = destinationService.updateDestination(ddto);

		if (res > 0) {
			return "common/PopupClose";
		} else {
			return "common/PopupClose";
		}
	}

	@RequestMapping(value = "adminLogout")
	public String adminLogout() {
		return "redirect:logout.do";
	}
}
