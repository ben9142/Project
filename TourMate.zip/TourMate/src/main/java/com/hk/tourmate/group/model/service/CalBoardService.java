package com.hk.tourmate.group.model.service;

import java.util.List;
import java.util.Map;

import com.hk.tourmate.group.dto.CalBoardDto;

public interface CalBoardService {

	public int insertSchedule(CalBoardDto cdto);
	
	List<CalBoardDto> selectAll(Map<String, String>map);
	
	public int updateSchedule(CalBoardDto cdto);
	
	public int deleteSchedule(int gseq);
}
