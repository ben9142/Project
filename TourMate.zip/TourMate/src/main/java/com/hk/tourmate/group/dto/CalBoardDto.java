package com.hk.tourmate.group.dto;

import java.util.Date;

public class CalBoardDto {
	
	private int cseq;
	private	int gseq;
	private String stime;
	private String ltime;
	private String title;
	private String content;
	private String mdate;
	private Date date;
	
	public CalBoardDto() {
		// TODO Auto-generated constructor stub
	}

	public CalBoardDto(int cseq, int gseq, String stime, String ltime, String title, String content, String mdate,
			Date date) {
		super();
		this.cseq = cseq;
		this.gseq = gseq;
		this.stime = stime;
		this.ltime = ltime;
		this.title = title;
		this.content = content;
		this.mdate = mdate;
		this.date = date;
	}

	public int getCseq() {
		return cseq;
	}

	public void setCseq(int cseq) {
		this.cseq = cseq;
	}

	public int getGseq() {
		return gseq;
	}

	public void setGseq(int gseq) {
		this.gseq = gseq;
	}

	public String getStime() {
		return stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getLtime() {
		return ltime;
	}

	public void setLtime(String ltime) {
		this.ltime = ltime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getMdate() {
		return mdate;
	}

	public void setMdate(String mdate) {
		this.mdate = mdate;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "CalBoardDto [cseq=" + cseq + ", gseq=" + gseq + ", stime=" + stime + ", ltime=" + ltime + ", title="
				+ title + ", content=" + content + ", mdate=" + mdate + ", date=" + date + "]";
	}
	
	
	
	
}
