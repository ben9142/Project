package com.hk.tourmate.login.model.service;

import com.hk.tourmate.login.dto.DestinationDto;

public interface DestinationService {

	public int insertDestination(DestinationDto ddto);
	public int updateDestination(DestinationDto ddto);
}
