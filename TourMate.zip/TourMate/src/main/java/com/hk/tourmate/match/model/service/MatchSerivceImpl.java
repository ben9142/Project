package com.hk.tourmate.match.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MatchDto;
import com.hk.tourmate.match.dto.MessageBoxDto;
import com.hk.tourmate.match.model.dao.MatchDao;

@Service
public class MatchSerivceImpl implements MatchSerivce {

	@Autowired
	private MatchDao matchDao;
	
	@Override
	public MatchDto matchingList(String id) {
		return matchDao.matchingList(id);
	}

	@Override
	public List<MatchDto> matchDuoList(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.matchDuoList(map);
	}
	
	@Override
	public List<GroupDto> matchgroupList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return matchDao.matchgroupList(map);
	}

	@Override
	public List<MatchDto> soloSerch(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.soloSerch(map);
	}

	@Override
	public List<GroupDto> groupSerch(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.groupSerch(map);
	}

	@Override
	public GroupDto matchGroupQseq(int gseq) {
		// TODO Auto-generated method stub
		return matchDao.matchGroupQseq(gseq);
	}

	@Override
	public int groupMatch(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.groupMatch(map);
	}

	@Override
	public List<String> inviteCheck(int gseq) {
		// TODO Auto-generated method stub
		return matchDao.inviteCheck(gseq);
	}

	@Override
	public int inviteGroup(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.inviteGroup(map);
	}

	@Override
	public int sendMsgcheck(Map<String, String> map) {
		// TODO Auto-generated method stub
		return matchDao.sendMsgcheck(map);
	}



	
}
