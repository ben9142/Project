package com.hk.tourmate.group.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.RecommendationDto;

@Repository
public class RecommendationDaoImpl implements RecommendationDao {
	
	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public List<RecommendationDto> recommendationList() {
		List<RecommendationDto> list = new ArrayList<>();
		list = sqlSession.selectList("tourmate.selectListAll");
		
		return list;
	}

	@Override
	public int insertRecommendation(RecommendationDto recDto) {
		// TODO Auto-generated method stub
		
		int res = 0;
		res = sqlSession.insert("tourmate.insertRecommendation", recDto);
		
		return res;
	}

	@Override
	public int delRecommendation(int rseq) {
		// TODO Auto-generated method stub
		int res = 0;
		res = sqlSession.insert("tourmate.delRecommendation", rseq);
		
		return res;
	}

	@Override
	public RecommendationDto detailRecommendation(int rseq) {
		// TODO Auto-generated method stub
		RecommendationDto recDto = sqlSession.selectOne("tourmate.detailRecommendation", rseq);
		
		return recDto;
	}

	@Override
	public int updateRecommendation(RecommendationDto recDto) {
		// TODO Auto-generated method stub
		int res = 0;
		res = sqlSession.insert("tourmate.updateRecommendation", recDto);
		
		return res;
	}

	@Override
	public List<RecommendationDto> recommendRList(String country, String city) {
		List<RecommendationDto> list = new ArrayList<>();
		Map<String, String> map = new HashMap<>(); 
		map.put("country", country);
		map.put("city", city);
		list = sqlSession.selectList("tourmate.recommendRList", map);
		
		return list;
	}



}
