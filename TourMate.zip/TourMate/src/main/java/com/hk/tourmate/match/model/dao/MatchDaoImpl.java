package com.hk.tourmate.match.model.dao;



import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MatchDto;
import com.hk.tourmate.match.dto.MessageBoxDto;

@Repository
public class MatchDaoImpl implements MatchDao {
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public MatchDto matchingList(String id) {
		MatchDto lists = new MatchDto();
		lists = sqlSession.selectOne("matching.selectMatch",id);		
		return lists;
	}

	@Override
	public List<MatchDto> matchDuoList(Map<String, String> map) {
		List<MatchDto> list = new ArrayList<MatchDto>();
		list = sqlSession.selectList("matching.matchDuoList",map);
		return list;
	}
	
	@Override
	public List<GroupDto> matchgroupList(Map<String, Object> map) {
		List<GroupDto> list = new ArrayList<GroupDto>();
		list = sqlSession.selectList("matching.matchgroupList",map);
		return list;
	}

	@Override
	public List<MatchDto> soloSerch(Map<String, String> map) {
		List<MatchDto> list = new ArrayList<MatchDto>();
		list = sqlSession.selectList("matching.soloSerch",map);		
		return list;
	}

	@Override
	public List<GroupDto> groupSerch(Map<String, String> map) {
		List<GroupDto> list = new ArrayList<GroupDto>();
		list = sqlSession.selectList("matching.groupSerch",map);
		return list;
	}

	@Override
	public GroupDto matchGroupQseq(int gseq) {		
		GroupDto  dto = new GroupDto();
		dto = sqlSession.selectOne("matching.matchGroupQseq",gseq);		
		return dto;
	}

	@Override
	public int groupMatch(Map<String, String> map) {
		int res = 0;
		res = sqlSession.insert("matching.groupMatch", map);
		return res;
	}

	@Override
	public List<String> inviteCheck(int gseq) {
		List<String> list = new ArrayList<String>();
		list = sqlSession.selectList("matching.inviteCheck",gseq);
		return list;
	}

	@Override
	public int inviteGroup(Map<String, String> map) {
		int res = 0;
		res = sqlSession.insert("matching.inviteGroup", map);
		return res;
	}

	@Override
	public int sendMsgcheck(Map<String, String> map) {
		int res = 0;
		
		MessageBoxDto dto = sqlSession.selectOne("matching.sendMsgcheck",map);
		
		if(dto==null||dto.getId()==null){
			res = 1;
		}		
		return res;
	}



}
