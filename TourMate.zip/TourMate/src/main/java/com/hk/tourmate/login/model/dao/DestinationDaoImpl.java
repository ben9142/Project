package com.hk.tourmate.login.model.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.login.dto.DestinationDto;

@Repository
public class DestinationDaoImpl implements DestinationDao{

	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public int insertDestination(DestinationDto ddto) {
		int res = 0;
		
		res = sqlsession.insert("tourmate.insertDestination", ddto);
		
		return res;
	}

	@Override
	public int updateDestinationi(DestinationDto ddto) {
		int res = 0;
		
		res = sqlsession.update("tourmate.updateDestination", ddto);
		
		return res;
	}

}
