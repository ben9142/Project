package com.hk.tourmate.login.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.login.dto.DestinationDto;
import com.hk.tourmate.login.model.dao.DestinationDao;

@Service
public class DestinationServiceImpl implements DestinationService{

	@Autowired
	private DestinationDao destinationDao;

	@Override
	public int insertDestination(DestinationDto ddto) {
		// TODO Auto-generated method stub
		return destinationDao.insertDestination(ddto);
	}

	@Override
	public int updateDestination(DestinationDto ddto) {
		return destinationDao.updateDestinationi(ddto);
	}
}
