package com.hk.tourmate.match.model.service;

import java.util.List;

import com.hk.tourmate.match.dto.TourDiaryDto;

public interface TourDiaryService {
	public int insertDiary(String id);
	public List<TourDiaryDto> tourDiaryList(String id, int pageNum);
	public List<TourDiaryDto> getTourContent(TourDiaryDto dto);
	public int groupClose(String id);
	public int myGroupClose();
	public int dataMove();
	public int delDiary(TourDiaryDto dto);
	public List<String> insertIdList(String id);
	public int diaryCnt(String id);
}
