package com.hk.tourmate.group.model.service;

import java.util.List;

import com.hk.tourmate.group.dto.TalkBoardDto;

public interface TalkBoardService {

	public int insertTalk(TalkBoardDto tdto);
	public List<TalkBoardDto> talkList(int gseq);
}
