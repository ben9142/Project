package com.hk.tourmate.group.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hk.tourmate.group.dto.CalBoardDto;
import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.group.model.service.CalBoardService;
import com.hk.tourmate.group.model.service.GroupService;
import com.hk.tourmate.match.dto.MyGroupDto;
import com.hk.tourmate.match.model.service.MyGroupService;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;
import org.springframework.web.util.WebUtils;

import com.hk.tourmate.common.Util;
import com.hk.tourmate.group.dto.RecommendationDto;
import com.hk.tourmate.group.dto.TalkBoardDto;
import com.hk.tourmate.group.model.service.RecommendationService;
import com.hk.tourmate.group.model.service.TalkBoardService;
import com.hk.tourmate.login.dto.MemberDto;

@Controller
public class GroupController {
	
	Logger logger = LoggerFactory.getLogger(GroupController.class);

	@Autowired
	private CalBoardService calboardservice;
	@Autowired
	private GroupService groupservice;
	@Autowired
	private MyGroupService mygroupservice;
	@Autowired
	private RecommendationService recommendationService;
	@Autowired
	private TalkBoardService talkboardService;
	
	
	@RequestMapping(value="insertSchedule", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Map<String, Boolean> insertSchedule(CalBoardDto cdto, Model model){
		int res = 0;
		boolean lc = false;
		
		res = calboardservice.insertSchedule(cdto);
		if(res>0){
			lc = true;
		}
		Map<String, Boolean> rMap = new HashMap<>();
		rMap.put("lc", lc);
		
		return rMap;
	}
	
	@RequestMapping(value="selectSchedule", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<CalBoardDto> selectAll(int gseq, String mdate, Model model){
		
		Map<String, String>map = new HashMap<>();
		map.put("gseq", String.valueOf(gseq));
		map.put("mdate", mdate);
		
		List<CalBoardDto> lists = calboardservice.selectAll(map);
		
		return lists;
	}
	
	
	
	//그룹 생성
	@RequestMapping(value="insertGroup", method = {RequestMethod.GET, RequestMethod.POST})
	public String insertGroup(GroupDto gdto, String id){
		int res = 0;
		int rres = 0;

		res = groupservice.insertGroup(gdto);
		rres = mygroupservice.insertMyGroup(gdto.getLeader());
		
		if(res>0){
			if(rres>0){
				return "common/PopupClose";
			}
			return "match/matchList";
		}
		return "match/matchList";
	}
	
	@RequestMapping(value = "insertGroupPage")
	public String insertGroupPage(Model model, HttpSession session){
		
		MemberDto mdto = (MemberDto)session.getAttribute("loginPerson");
		model.addAttribute("dto", mdto);
		
		return "match/createGroup";
	}
	
	@RequestMapping(value = "groupMain")
	public String groupPage(){
		return "group/groupMain";
	}
	
	
	@RequestMapping(value = "matchList")
	public String matchPage(){
			
			
		return "match/matchList";
	}
	//일정 수정 팝업 이동
	@RequestMapping(value="changeSchedulePage")
	public String changeSchedule(int gseq, String sdate, String ldate, Model model){
		
		model.addAttribute("gseq", gseq);
		model.addAttribute("sdate", sdate);
		model.addAttribute("ldate", ldate);
		return "group/changeSchedule";
	}
	//일정 수정
	@RequestMapping(value="changeSchedule")
	public String changeSchedule(GroupDto gdto){
		
		int res = 0;
		res = groupservice.changeSchedule(gdto);
		
		if(res > 0){
			return "common/PopupClose";
		}else{
			return "redirect : changeSchedulePage.do?gseq=" + gdto.getGseq();
		}
	}
	
	@RequestMapping(value = "updateSchedule")
	@ResponseBody
	public Map<String, Boolean> updateSchedule(CalBoardDto cdto, Model model){
		int res = 0;
		boolean lc = false;
		
		res = calboardservice.updateSchedule(cdto);
		if(res>0){
			lc = true;
		}
		Map<String, Boolean> rMap = new HashMap<>();
		rMap.put("lc", lc);
		
		return rMap;
	}
	
	
	
	@RequestMapping(value = "deleteSchedule")
	@ResponseBody
	public Map<String, Boolean> deleteSchedule(int cseq, Model model){
		int res = 0;
		boolean lc = false;
		
		res = calboardservice.deleteSchedule(cseq);
		if(res>0){
			lc = true;
		}
		Map<String, Boolean> rMap = new HashMap<>();
		rMap.put("lc", lc);
		
		return rMap;
	}
	
	@RequestMapping(value = "myGroup")
	@ResponseBody
	public List<GroupDto> myGroup(String id, Model model){
		
		List<GroupDto> mygroupLists = new ArrayList<>();
		mygroupLists = mygroupservice.myGroupList(id);
				
		return mygroupLists;
	}
	
	//스케줄 개수 출력
	@RequestMapping(value="scheduleCount")
	@ResponseBody
	public int scheduleCount(String mdate, int gseq){
		
		Map<String, String> map = new HashMap<>();
		map.put("mdate", mdate);
		map.put("gseq", String.valueOf(gseq));
		
		System.out.println("mdatemdateatmdfadfmsaf : " + map);
		int res = groupservice.scheduleCount(map);
		
		return res;
	}
	
	// 관리자 페이지 이동
	@RequestMapping(value="adminPage", method = {RequestMethod.GET, RequestMethod.POST})
	public String adminPage() {
		return "admin/adminMain";
	}
	
	// 추천서비스목록 조회
	@RequestMapping(value="recServiceList", method = {RequestMethod.GET, RequestMethod.POST})
	public String recServiceList(Model model) {
		
		List<RecommendationDto> lists = recommendationService.selectAll();
		model.addAttribute("list",lists);
		
		return "admin/recServiceList";
	}
	
	// 추천서비스 추가폼 이동
	@RequestMapping(value="recServiceInsert", method = {RequestMethod.GET, RequestMethod.POST})
	public String recServiceInsert() {
		return "admin/recServiceI";
	}
	
	
	// 추천서비스 추가
	@Autowired
	private com.hk.tourmate.group.model.service.Validate fileValidator;
	
	@RequestMapping(value="recommendAdd", method = {RequestMethod.GET, RequestMethod.POST})
	public String recommendAdd(HttpServletRequest request,
			RecommendationDto recommendationDto, BindingResult result) {
		
		logger.info("file add");
		
		int res = 0;
		fileValidator.setJspPath("recServiceI");
		fileValidator.validate(recommendationDto, result);
		
		if(result.hasErrors()) {
			return "admin/recServiceI";
		}
		
		MultipartFile file = recommendationDto.getFile();
		String filename = file.getOriginalFilename();
		
		//uploadfile.jsp에서 사용할 객체
		RecommendationDto fileobj = new RecommendationDto();
		fileobj.setCountry(recommendationDto.getCountry());
		fileobj.setCity(recommendationDto.getCity());
		
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		try {
			inputStream = file.getInputStream();
			String path = WebUtils.getRealPath(request.getSession().getServletContext(),"/resources/img/admin");
			
			File newFile = new File(path+"/"+Util.getCurrentDate()+"_"+filename);
			fileobj.setImg("resources/img/admin/"+Util.getCurrentDate()+"_"+filename);
			System.out.println(path);
			if(!newFile.exists()) {
				newFile.createNewFile();
			}
			
			outputStream = new FileOutputStream(newFile);
			
			int read = 0;
			byte[] b = new byte[(int)file.getSize()];
			
			while((read=inputStream.read(b))!= -1) {
				outputStream.write(b, 0, read);
			}
			
			res = recommendationService.insertRecommendation(fileobj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if(res>0) {
			return "common/PopupClose";
		} else {
			return "admin/recServiceI";
		}
	}
	
	// 추천서비스 삭제
	@RequestMapping(value="recServiceDel", method = {RequestMethod.GET, RequestMethod.POST})
	public String recommendDel(int rseq, String img, Model model, HttpServletRequest request){
		int res = recommendationService.delRecommendation(rseq);
		
		String filename = img.substring(img.lastIndexOf("/")+1);
		
		if(res>0) {
			try {
				
				String path = WebUtils.getRealPath(request.getSession().getServletContext(),"/resources/img/admin");
				File newFile = new File(path+"/"+filename);
				
				if(newFile.exists()) {
					// 등록된 사진 파일 삭제
					newFile.delete();
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "redirect:/recServiceList.do";	
	}
	
	// 추천서비스 수정 폼
	@RequestMapping(value="recServiceUpdateForm", method = {RequestMethod.GET, RequestMethod.POST})
	public String recServiceUpdateForm(int rseq, Model model){
		
		RecommendationDto recDto = recommendationService.detailRecommendation(rseq);
		model.addAttribute("recDto",recDto);
		
		return "admin/recServiceU";
	}
	
	// 추천서비스 수정
	@RequestMapping(value="recServiceUpdate", method = {RequestMethod.GET, RequestMethod.POST})
	public String recommendUpdate(Model model, HttpServletRequest request,
			RecommendationDto recommendationDto, BindingResult result, int rseq, String img) {
		
		int res = 0;
		String prevName = img.substring(img.lastIndexOf("/")+1);
		
		fileValidator.setJspPath("recServiceU");
		fileValidator.validate(recommendationDto, result);
		
		if(result.hasErrors()) {
			
			RecommendationDto recDto = recommendationService.detailRecommendation(rseq);
			model.addAttribute("recDto",recDto);
			
			return "admin/recServiceU";
		}
		
		MultipartFile file = recommendationDto.getFile();
		String filename = file.getOriginalFilename();
		
		//uploadfile.jsp에서 사용할 객체
		RecommendationDto fileobj = new RecommendationDto();
		
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		try {
			inputStream = file.getInputStream();
			String path = WebUtils.getRealPath(request.getSession().getServletContext(),"/resources/img/admin");
			
			System.out.println(path);
			// 이전파일 삭제
			File prevFile = new File(path+"/"+prevName);
			
			if(prevFile.exists()) {
				prevFile.delete();
			}
			
			//수정된 파일 등록
			File newFile = new File(path+"/"+Util.getCurrentDate()+"_"+filename);
			fileobj.setRseq(rseq);
			fileobj.setImg("resources/img/admin/"+Util.getCurrentDate()+"_"+filename);
			
			if(!newFile.exists()) {
				newFile.createNewFile();
			}
			
			outputStream = new FileOutputStream(newFile);
			
			int read = 0;
			byte[] b = new byte[(int)file.getSize()];
			
			while((read=inputStream.read(b))!= -1) {
				outputStream.write(b, 0, read);
			}
			
			res = recommendationService.updateRecommendation(fileobj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if(res>0) {
			return "common/PopupClose";
		} else {
			return "admin/recServiceU";
		}
	}
	
	//JSJ
	//그룹 대화형 게시판 이동
	@RequestMapping(value="talkPage", method = {RequestMethod.GET, RequestMethod.POST})
	public String talkPage(){
		return "group/groupTalk";
	}
	
	//그룹 대화형 게시판 리스트 출력
	@RequestMapping(value="talkList", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<TalkBoardDto> talkBoard(int gseq, Model model, HttpSession session){
		
		
		List<TalkBoardDto> tlist = talkboardService.talkList(gseq);
		System.out.println("listlistsltisiltistlit : " + tlist.get(1).getMemberDto().getImg());
		return tlist;
	}
	
	// 그룹 대화형 게시판 글 작성
	@RequestMapping(value="insertTalk", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public Map<String, Boolean> insertTalk(TalkBoardDto tdto, Model model, HttpSession session){
		int res = 0;
		boolean flag = false;
		res = talkboardService.insertTalk(tdto);
		Map<String, Boolean> rMap = new HashMap<>();
		if(res>0){
			flag = true;
		}
		rMap.put("flag", flag);
		
		return rMap;
	}
	
	// 그룹페이지 이동
	@RequestMapping(value="groupJoin", method = {RequestMethod.GET, RequestMethod.POST})
	public String groupJoin(HttpSession session, Model model, int gseq) {
		GroupDto groupDto = groupservice.groupJoin(gseq);
		MemberDto mdto = (MemberDto)session.getAttribute("loginPerson");
		List<String> groupMemberList = groupservice.myGroupMember(gseq);

		
		model.addAttribute("groupDto",groupDto);
		model.addAttribute("groupMemberList",groupMemberList);
		model.addAttribute("mdto", mdto);
		
		return "group/groupMain";
	}

	// 그룹수정 (제목, 내용)
	@RequestMapping(value="updateGroup", method = {RequestMethod.GET, RequestMethod.POST})
	public String updateGroup(GroupDto gdto){
		
		int res = groupservice.updateGroup(gdto);
		System.out.println("sdfdsfdsffdsfsdsdfsdfsdfsd : " + gdto.getGseq());
		if(res>0){
			return "redirect:groupJoin.do?gseq=" + gdto.getGseq();
		}
		
		return "redirect:groupJoin.do?gseq=" + gdto.getGseq();
	}
	
	// 그룹탈퇴
	@RequestMapping(value="leavegroup")
	public String leavegroup(Model model, int gseq, String leader
			, HttpSession session){
		MemberDto mdto = (MemberDto)session.getAttribute("loginPerson");
		
		// 리더의 여부확인
		if(mdto.getId().equals(leader)) {
			List<String> list = mygroupservice.changeLeaderList(mdto.getId(), gseq);
			model.addAttribute("list",list);
			model.addAttribute("gseq",gseq);
			return "group/changeLeader";
		} else {
			int res = groupservice.leavegroup(mdto.getId(), gseq);
			if(res > 0) {
				String url = "matchList.do";
				model.addAttribute("url",url);
				return "common/PopupCloseAndUrlMove";
			}
		}
		return "redirect:errorPage.do";
	}
	
	// 그룹장 위임
	@RequestMapping(value="changeLeader")
	public String changeLeader(Model model, String selId, int gseq, HttpSession session) {
		MemberDto mdto = (MemberDto)session.getAttribute("loginPerson");
		int res = groupservice.changeLeader(selId, gseq);
		
		if(res > 0) {
			res = groupservice.leavegroup(mdto.getId(), gseq);
			if(res > 0) {
				String url = "matchList.do";
				model.addAttribute("url",url);
				return "common/PopupCloseAndUrlMove";		
			} else {
				return "redirect:errorPage.do";
			}
		}
		return "redirect:errorPage.do";
	}
	
	// 그룹 삭제
	@RequestMapping(value="delGroup")
	public String delGroup(Model model, int gseq) {
		int res = groupservice.delGroup(gseq);
		
		if(res>0) {
			String url = "matchList.do";
			model.addAttribute("url",url);
			return "common/PopupCloseAndUrlMove";		
		} else {
			return "redirect:errorPage.do";
		}
	}
	
	// 나에게 맞는 추천서비스 조회
	@RequestMapping(value="recommendRList", method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<RecommendationDto> recommendRList(Model model, String country, String city) {
		
		List<RecommendationDto> list = recommendationService.recommendRList(country, city);
		return list;
	}
}
