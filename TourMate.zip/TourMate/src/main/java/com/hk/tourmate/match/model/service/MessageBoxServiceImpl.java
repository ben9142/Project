package com.hk.tourmate.match.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.match.dto.MessageBoxDto;
import com.hk.tourmate.match.model.dao.MessageBoxDao;

@Service
public class MessageBoxServiceImpl implements MessageBoxService {

	@Autowired
	private MessageBoxDao messageBoxDao;

	@Override
	public int messageRejection(int mseq) {
		// TODO Auto-generated method stub
		return messageBoxDao.messageRejection(mseq);
	}

	@Override
	public int inviteMessageAccept(String id, int invite_group) {
		// TODO Auto-generated method stub
		return messageBoxDao.inviteMessageAccept(id, invite_group);
	}

	@Override
	public int requestMessageAccept(String send_id, int invite_group) {
		// TODO Auto-generated method stub
		return messageBoxDao.requestMessageAccept(send_id, invite_group);
	}

	@Override
	public List<MessageBoxDto> messageList(String id, int pageNum) {
		// TODO Auto-generated method stub
		return messageBoxDao.messageList(id, pageNum);
	}

	@Override
	public int getMessageCnt(String id) {
		// TODO Auto-generated method stub
		return messageBoxDao.getMessageCnt(id);
	}
}
