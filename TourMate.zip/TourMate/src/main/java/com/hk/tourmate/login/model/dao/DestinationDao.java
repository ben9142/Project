package com.hk.tourmate.login.model.dao;

import com.hk.tourmate.login.dto.DestinationDto;

public interface DestinationDao {

	public int insertDestination(DestinationDto ddto);
	public int updateDestinationi(DestinationDto ddto);
}
