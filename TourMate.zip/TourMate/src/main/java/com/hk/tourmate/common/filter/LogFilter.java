package com.hk.tourmate.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogFilter implements Filter {

private Logger logger = LoggerFactory.getLogger(LogFilter.class);
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest)req;
		
		String RemoteAddr = StringUtils.defaultString(request.getRemoteAddr());
		
		String uri = StringUtils.defaultString(request.getRequestURI());
		String url = StringUtils.defaultString(request.getRequestURL().toString());
		String queryString = StringUtils.defaultString(request.getQueryString());
		
		String referer = StringUtils.defaultString(request.getHeader("referer"));
		String agent = StringUtils.defaultString(request.getHeader("User-Agent"));
		
		System.out.println("remoteAddr : " + RemoteAddr);
		System.out.println("uri : " + uri);
		System.out.println("url : " + url);
		System.out.println("queryString : " + queryString);
		System.out.println("referer : " + referer);
		System.out.println("user-agent : " + agent);
		
		StringBuffer result = new StringBuffer();
		
		result.append(" : ").append(RemoteAddr)
		.append(" : ").append(uri)
		.append(" : ").append(url)
		.append(" : ").append(queryString)
		.append(" :").append(referer)
		.append(" : ").append(agent);
		
		logger.info("LOG FILTER : " + result);
		
		chain.doFilter(request, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
