package com.hk.tourmate.login.model.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hk.tourmate.login.dto.MemberDto;
import com.hk.tourmate.login.model.dao.MemberDao;

@Service
public class MemberServiceImpl implements MemberService{

	@Autowired
	private MemberDao memberDao;
	
	@Override
	@Transactional(readOnly = false)
	public int insertMember(MemberDto mdto) {
		// TODO Auto-generated method stub
		return memberDao.insertMember(mdto);
	}

	@Override
	public MemberDto loginChk(Map<String, String> map) {
		// TODO Auto-generated method stub
		return memberDao.loginChk(map);
	}

	@Override
	public String checkId(String id) {
		return memberDao.checkId(id);
	}

	@Override
	public MemberDto myInfo(String id) {
		return memberDao.myInfo(id);
	}

	@Override
	public int deleteInfo(String id) {
		return memberDao.deleteInfo(id);
	}

	@Override
	public int updateInfo(MemberDto mdto) {
		return memberDao.updateInfo(mdto);
	}

}
