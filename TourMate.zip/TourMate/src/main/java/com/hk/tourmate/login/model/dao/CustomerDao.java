package com.hk.tourmate.login.model.dao;

import java.util.List;

import com.hk.tourmate.login.dto.CustomerDto;

public interface CustomerDao {

//	public List<CustomerDto> selectAll();
}
