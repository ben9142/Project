package com.hk.tourmate.match.model.service;

import java.util.List;

import com.hk.tourmate.match.dto.MessageBoxDto;

public interface MessageBoxService {
	public List<MessageBoxDto> messageList(String id, int pageNum);
	public int messageRejection(int mseq);
	public int inviteMessageAccept(String id, int invite_group);
	public int requestMessageAccept(String send_id, int invite_group);
	public int getMessageCnt(String id);
}
