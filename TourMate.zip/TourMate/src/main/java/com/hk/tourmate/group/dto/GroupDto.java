package com.hk.tourmate.group.dto;

import com.hk.tourmate.match.dto.MyGroupDto;

public class GroupDto {

	private int gseq;
	private String gname;
	private String gcontent;
	private String country;
	private String city;
	private String sdate;
	private String ldate;
	private String enabled;
	private String datamove;
	private String leader;
	private int cnt;
	
	private MyGroupDto mygroupDto;
	
	public GroupDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	public MyGroupDto getMygroupDto() {
		return mygroupDto;
	}

	public void setMygroupDto(MyGroupDto mygroupDto) {
		this.mygroupDto = mygroupDto;
	}

	public GroupDto(int gseq, String gname, String gcontent, String country, String city, String sdate, String ldate,
			String enabled, String leader) {
		super();
		this.gseq = gseq;
		this.gname = gname;
		this.gcontent = gcontent;
		this.country = country;
		this.city = city;
		this.sdate = sdate;
		this.ldate = ldate;
		this.enabled = enabled;
		this.leader = leader;
	}

	public int getGseq() {
		return gseq;
	}

	public void setGseq(int gseq) {
		this.gseq = gseq;
	}

	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public String getGcontent() {
		return gcontent;
	}

	public void setGcontent(String gcontent) {
		this.gcontent = gcontent;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getLdate() {
		return ldate;
	}

	public void setLdate(String ldate) {
		this.ldate = ldate;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLeader() {
		return leader;
	}

	public void setLeader(String leader) {
		this.leader = leader;
	}

	public String getDatamove() {
		return datamove;
	}

	public void setDatamove(String datamove) {
		this.datamove = datamove;
	}

	@Override
	public String toString() {
		return "GroupDto [gseq=" + gseq + ", gname=" + gname + ", gcontent=" + gcontent + ", country=" + country
				+ ", city=" + city + ", sdate=" + sdate + ", ldate=" + ldate + ", enabled=" + enabled + ", datamove="
				+ datamove + ", leader=" + leader + ", cnt=" + cnt + ", mygroupDto=" + mygroupDto + "]";
	}	
	
}
