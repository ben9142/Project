package com.hk.tourmate.match.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MyGroupDto;

@Repository
public class MyGroupDaoImpl implements MyGroupDao{

	@Autowired
	private SqlSession sqlsession;

	@Override
	public List<GroupDto> myGroupList(String id) {
		List<GroupDto> list = new ArrayList<>();
		list = sqlsession.selectList("tourmate.myGroupList", id);
		
		return list;
	}
	
	@Override
	public int insertMyGroup(String id) {
		int res = 0;
		
		res = sqlsession.insert("tourmate.insertMyGroup", id);
		
		return res;
	}

	@Override
	public List<String> changeLeaderList(String id, int gseq) {
		List<String> list = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("gseq", String.valueOf(gseq));
		
		list = sqlsession.selectList("tourmate.changeLeaderList",map);
		
		return list;
	}
	
}
