package com.hk.tourmate.common;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Util {
	private  String utilData;
	private  String utilId;
	
	public Util() {
		// TODO Auto-generated constructor stub
	}
	
	public String getUtilId() {
		return utilId;
	}

	public void setUtilId(String id) {
		String dataId = "";
		String Data ="";
		if(id.length()>8){
			dataId = id.substring(0,8);			
			Data = dataId+"..";
			utilId = Data;
		}else{
			Data = id;
			utilId = Data;
		}
		
		this.utilId = Data;
	}

	
	
	public  String getUtilData() {
		return utilData;
	}


	public  void setUtilData(String data) {
		
		String dataIndex = "";
		String dataLast = "";
		String Data ="";
		if(data.length()>6){
			dataIndex = data.substring(0,6);
			dataLast = data.substring(6);
			
			Data = dataIndex+"<br>"+dataLast;
			utilData = Data;
		}else{
			Data = data;
			utilData = Data;
		}
		
		this.utilData = Data;
	}
	
	public static String getCurrentDate(){
		 Date date = new Date(System.currentTimeMillis()); 
	     SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss"); 
	     
	     return format.format(date); 
	}
	
	public static String getImgName(String imgName) {
		if(imgName.length()>30) {
			imgName = imgName.substring(0, 30) + "...";
		}
		
		return imgName;
	}
	
	public static String getImgNameBr(String imgName) {
		String ImgSrc = imgName.substring(0, imgName.lastIndexOf("/")+1);
		String ImgName = imgName.substring(imgName.lastIndexOf("/")+1);
		
		return ImgSrc+"<br>"+ImgName;
	}
	
	public String getPrint(){
		String output = "테스트입니다";
		return output;
	}
	
//	public static String getMatchData(String data){
//		
//		utilData = data;
//		
//		String dataIndex = "";
//		String dataLast = "";
//		if(data.length()>5){
//			dataIndex = data.substring(0,6);
//			dataLast = data.substring(6);
//			
//			utilData = dataIndex+"<br>"+dataLast;
//		}		
//		//return dataIndex+"<br>"+dataLast;
//		return utilData;
//	}
}
