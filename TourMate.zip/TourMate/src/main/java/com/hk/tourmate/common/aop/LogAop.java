package com.hk.tourmate.common.aop;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogAop {

	public void before(JoinPoint joinpoint){
		Logger logger = LoggerFactory.getLogger(joinpoint.getTarget()+"");
		logger.info("======================logger 시작=====================");
		
		Object args[] = joinpoint.getArgs();
		
		if(args != null){
			logger.info("Method : " + joinpoint.getSignature().getName());
		}
	}
	
	public void after(JoinPoint joinpoint){
		Logger logger = LoggerFactory.getLogger(joinpoint.getTarget() + "");
		logger.info("====================logger 끝===================");
	}
	
	public void afterThrowing(JoinPoint joinpoint){
		Logger logger = LoggerFactory.getLogger(joinpoint.getTarget()+"");
		logger.info("에러 : " + joinpoint.getArgs());
		logger.info("에러 : " + joinpoint.toString());
	}
}
