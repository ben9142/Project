package com.hk.tourmate.match.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.RecommendationDto;
import com.hk.tourmate.match.dto.TourDiaryDto;

@Repository
public class TourDiaryDaoImpl implements TourDiaryDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public int insertDiary(String id) {
		int res = 0;
		System.out.println(id);
		res = sqlSession.insert("tourmate.insertTourDiary", id);
		
		return res;
	}

	@Override
	public int groupClose(String id) {
		int res = 0;
		res = sqlSession.update("tourmate.groupClose", id);
		
		return res;
	}

	@Override
	public int myGroupClose() {
		// TODO Auto-generated method stub
		int res = 0;
		res = sqlSession.update("tourmate.myGroupClose");
		
		return res;
	}

	@Override
	public int dataMove() {
		// TODO Auto-generated method stub
		int res = 0;
		res = sqlSession.update("tourmate.dataMove");
		
		return res;
	}


	@Override
	public List<TourDiaryDto> tourDiaryList(String id, int pageNum) {
		List<TourDiaryDto> list = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("pageNum", String.valueOf(pageNum));
		list = sqlSession.selectList("tourmate.diaryList", map);
		
		return list;
	}

	@Override
	public List<TourDiaryDto> getTourContent(TourDiaryDto dto) {
		List<TourDiaryDto> list = new ArrayList<>();
		list = sqlSession.selectList("tourmate.contentList", dto);
		
		return list;
	}

	@Override
	public int delDiary(TourDiaryDto dto) {
		int res = 0;
		System.out.println(dto.getCountry());
		System.out.println(dto.getSdate());
		System.out.println(dto.getLdate());
		System.out.println(dto.getId());
		res = sqlSession.delete("tourmate.delDiary", dto);
		
		return res;
	}

	@Override
	public List<String> insertIdList(String id) {
		List<String> list = new ArrayList<>();
		list = sqlSession.selectList("tourmate.insertIdList", id);
		
		return list;
	}

	@Override
	public int diaryCnt(String id) {
		int res=0;
		res = sqlSession.selectOne("tourmate.diaryCnt", id);
				
		return res;
	}

}
