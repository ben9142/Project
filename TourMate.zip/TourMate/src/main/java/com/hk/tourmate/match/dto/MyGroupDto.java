package com.hk.tourmate.match.dto;

import com.hk.tourmate.group.dto.GroupDto;

public class MyGroupDto {
	
	private int mgseq;
	private String id;
	private int gseq;
	private String enabled;
	private GroupDto gdto;
	
	public MyGroupDto() {
		// TODO Auto-generated constructor stub
	}

	public MyGroupDto(int mgseq, String id, int gseq) {
		super();
		this.mgseq = mgseq;
		this.id = id;
		this.gseq = gseq;
	}
	
	public MyGroupDto(int mgseq, String id, int gseq, GroupDto gdto) {
		super();
		this.mgseq = mgseq;
		this.id = id;
		this.gseq = gseq;
		this.gdto = gdto;
	}
		

	public MyGroupDto(int mgseq, String id, int gseq, String enabled, GroupDto gdto) {
		super();
		this.mgseq = mgseq;
		this.id = id;
		this.gseq = gseq;
		this.enabled = enabled;
		this.gdto = gdto;
	}

	public int getMgseq() {
		return mgseq;
	}

	public void setMgseq(int mgseq) {
		this.mgseq = mgseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getGseq() {
		return gseq;
	}

	public void setGseq(int gseq) {
		this.gseq = gseq;
	}

	public GroupDto getGdto() {
		return gdto;
	}

	public void setGdto(GroupDto gdto) {
		this.gdto = gdto;
	}	

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "MyGroupDto [mgseq=" + mgseq + ", id=" + id + ", gseq=" + gseq + ", enabled=" + enabled + ", gdto="
				+ gdto + "]";
	}

	
}
