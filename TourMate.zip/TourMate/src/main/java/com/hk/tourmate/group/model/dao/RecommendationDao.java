package com.hk.tourmate.group.model.dao;

import java.util.List;

import com.hk.tourmate.group.dto.RecommendationDto;

public interface RecommendationDao {
	public List<RecommendationDto> recommendationList();
	public int insertRecommendation(RecommendationDto recDto);
	public int delRecommendation(int rseq);
	public RecommendationDto detailRecommendation(int rseq);
	public int updateRecommendation(RecommendationDto recDto);
	public List<RecommendationDto> recommendRList(String country, String city);
}
