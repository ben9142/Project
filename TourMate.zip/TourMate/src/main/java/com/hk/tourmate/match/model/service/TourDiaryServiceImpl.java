package com.hk.tourmate.match.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.match.dto.TourDiaryDto;
import com.hk.tourmate.match.model.dao.TourDiaryDao;

@Service
public class TourDiaryServiceImpl implements TourDiaryService {

	@Autowired
	private TourDiaryDao tourDiaryDao;
	
	@Override
	public int insertDiary(String id) {
		// TODO Auto-generated method stub
		return tourDiaryDao.insertDiary(id);
	}

	@Override
	public int groupClose(String id) {
		// TODO Auto-generated method stub
		return tourDiaryDao.groupClose(id);
	}

	@Override
	public int myGroupClose() {
		// TODO Auto-generated method stub
		return tourDiaryDao.myGroupClose();
	}

	@Override
	public int dataMove() {
		// TODO Auto-generated method stub
		return tourDiaryDao.dataMove();
	}


	@Override
	public List<TourDiaryDto> tourDiaryList(String id, int pageNum) {
		// TODO Auto-generated method stub
		return tourDiaryDao.tourDiaryList(id,pageNum);
	}

	@Override
	public List<TourDiaryDto> getTourContent(TourDiaryDto dto) {
		// TODO Auto-generated method stub
		return tourDiaryDao.getTourContent(dto);
	}

	@Override
	public int delDiary(TourDiaryDto dto) {
		// TODO Auto-generated method stub
		return tourDiaryDao.delDiary(dto);
	}

	@Override
	public List<String> insertIdList(String id) {
		// TODO Auto-generated method stub
		return tourDiaryDao.insertIdList(id);
	}

	@Override
	public int diaryCnt(String id) {
		// TODO Auto-generated method stub
		return tourDiaryDao.diaryCnt(id);
	}
	
}
