package com.hk.tourmate.group.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.match.dto.MyGroupDto;

@Repository
public class GroupDaoImpl implements GroupDao{
	
	@Autowired
	private SqlSession sqlSession;
	
	public int insertGroup(GroupDto gdto){
		int res = 0;
		
		res = sqlSession.insert("tourmate.insertGroup", gdto);
	
		return res;
	}

	@Override
	public GroupDto groupJoin(int gseq) {
		GroupDto groupDto = sqlSession.selectOne("tourmate.groupJoin", gseq);
		
		return groupDto;
	}

	@Override
	public int updateGroup(GroupDto gdto) {
		int res = 0;
		
		res = sqlSession.update("tourmate.updateGroup", gdto);
		
		return res;
	}

	@Override
	public int leavegroup(String id, int gseq) {
		int res = 0;
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("gseq", String.valueOf(gseq));
		res = sqlSession.update("tourmate.leavegroup", map);
		return res;
	}

	@Override
	public int changeLeader(String id, int gseq) {
		int res = 0;
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("gseq", String.valueOf(gseq));
		res = sqlSession.update("tourmate.changeLeader", map);
		
		return res;
	}

	@Override
	public int delGroup(int gseq) {
		int res = 0;
		res = sqlSession.delete("tourmate.delGroup", gseq);
		return res;
	}

	@Override
	public int scheduleCount(Map<String, String> map) {
		int res = 0;
		
		res = sqlSession.selectOne("tourmate.scheduleCount", map);
		
		return res;
	}

	@Override
	public List<String> myGroupMember(int gseq) {
		List<String> list = new ArrayList<>();
		list = sqlSession.selectList("tourmate.myGroupMember",gseq);
		
		return list;
	}

	@Override
	public int changeSchedule(GroupDto gdto) {
		int res = 0;
		res = sqlSession.update("tourmate.changeSchedule", gdto);
		
		return res;
	}

}
