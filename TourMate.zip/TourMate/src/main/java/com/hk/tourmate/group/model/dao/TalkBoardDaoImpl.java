package com.hk.tourmate.group.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.group.dto.TalkBoardDto;

@Repository
public class TalkBoardDaoImpl implements TalkBoardDao{

	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public int insertTalk(TalkBoardDto tdto) {
		int res = sqlsession.insert("tourmate.insertTalk", tdto);
		
		return res;
	}

	@Override
	public List<TalkBoardDto> talkList(int gseq) {
		
		List<TalkBoardDto> tlist = sqlsession.selectList("tourmate.talkList", gseq);
		
		return tlist;
	}

}
