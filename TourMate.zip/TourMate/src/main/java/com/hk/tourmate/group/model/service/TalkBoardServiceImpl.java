package com.hk.tourmate.group.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.tourmate.group.dto.TalkBoardDto;
import com.hk.tourmate.group.model.dao.TalkBoardDao;

@Service
public class TalkBoardServiceImpl implements TalkBoardService{

	@Autowired
	private TalkBoardDao talkboardDao;
	
	@Override
	public int insertTalk(TalkBoardDto tdto) {
		// TODO Auto-generated method stub
		return talkboardDao.insertTalk(tdto);
	}

	@Override
	public List<TalkBoardDto> talkList(int gseq) {
		// TODO Auto-generated method stub
		return talkboardDao.talkList(gseq);
	}

}
