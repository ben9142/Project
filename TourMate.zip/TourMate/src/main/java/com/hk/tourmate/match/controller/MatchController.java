package com.hk.tourmate.match.controller;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hk.tourmate.group.dto.GroupDto;
import com.hk.tourmate.login.dto.MemberDto;
import com.hk.tourmate.match.dto.MatchDto;
import com.hk.tourmate.match.dto.MessageBoxDto;
import com.hk.tourmate.match.dto.MyGroupDto;
import com.hk.tourmate.match.dto.TourDiaryDto;
import com.hk.tourmate.match.model.service.MatchSerivce;
import com.hk.tourmate.match.model.service.MessageBoxService;
import com.hk.tourmate.match.model.service.MyGroupService;
import com.hk.tourmate.match.model.service.TourDiaryService;

@Controller
public class MatchController {

	private static final Logger logger = LoggerFactory.getLogger(MatchController.class);

	@Autowired
	private TourDiaryService tourDiaryService;
	@Autowired
	private MessageBoxService messageBoxService;
	@Autowired
	private MatchSerivce matchService;
	@Autowired
	private MyGroupService myGroupService;

	@RequestMapping(value = "/matchId", method = { RequestMethod.GET, RequestMethod.POST })
	public MatchDto matchId(String id) {
		
		MatchDto dto = matchService.matchingList(id);
		
		return dto;
	}

	@RequestMapping(value = "/matchList", method = { RequestMethod.GET, RequestMethod.POST })
	public String list(Model model, HttpServletRequest request) {

		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");

		int res = tourDiaryService.groupClose(mdto.getId());
		if (res > 0) {
			res = tourDiaryService.myGroupClose();
		}

		List<GroupDto> myGroupLists = myGroupService.myGroupList(mdto.getId());
		MatchDto dto = matchId(mdto.getId());
		
		String img = dto.getMemberDto().getImg();
		int index = img.lastIndexOf("/"); // resources/img/common "/ " 구한거
		img = img.substring(index+1); // 파일명만 출력

		String id = dto.getId();
		String country = dto.getCountry();
		String city = dto.getCity();

		Map<String, String> map = new HashMap<String, String>();
		map.put("id", id);
		map.put("country", country);
		map.put("city", city);

		List<MatchDto> matchlist = matchService.matchDuoList(map);
		model.addAttribute("matchlist", matchlist);
		model.addAttribute("myGroupList", myGroupLists);
		model.addAttribute("memberImg", img);

		return "/match/matchList";
	}

	@RequestMapping(value = "/infoPage", method = { RequestMethod.GET, RequestMethod.POST })
	public String infoPage(Model model, String id) {
		MatchDto dto = matchService.matchingList(id);
		model.addAttribute("dto", dto);

		return "/match/infoDetail";
	}

	@RequestMapping(value = "/infoDetail", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public MatchDto infoDetail(Model model, String id, HttpSession session) {

		MatchDto dto = matchService.matchingList(id);
		
		if (dto != null) {
			
			session.setAttribute("dto", dto);
		}
		return dto;
	}
	
	@RequestMapping(value="matchgroupList",method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<GroupDto>  matchgroupList(Model model,HttpSession session,String id){
		
		Map<String, Object> map = new HashMap<String,Object>();
		MatchDto dto  =  matchId(id);		
		String country = dto.getCountry();
		String city = dto.getCity();		
				
		map.put("id", id);		
		map.put("country", country);		
		map.put("city", city);
		
		
		List<GroupDto> list = matchService.matchgroupList(map);

		return list;
	}
	
	
	//그룹검색
	
	@RequestMapping(value="groupSerch",method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<GroupDto>  groupSerch(Model model,HttpSession session,String serchtext){
				
		Map<String, String> map = new HashMap<String,String>();
		MemberDto dto = (MemberDto) session.getAttribute("loginPerson");		
		
		String id =dto.getId();		
		MatchDto dtos = matchId(id);	
		String country = dtos.getCountry();
		String city = dtos.getCity();
				
		map.put("id", id);		
		map.put("serchtext", serchtext);
		map.put("country", country);
		map.put("city", city);		
		
		List<GroupDto> list = matchService.groupSerch(map);
		return list;
	}
	
	
	
	
//	//개인 검색 
	@RequestMapping(value="/soloSerch",method = {RequestMethod.GET, RequestMethod.POST})
	public String soloSerch(Model model, HttpServletRequest request,String serchtext) {
	
		
	// 세션 아이디값 얻어오기
		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		List<GroupDto> myGroupLists = myGroupService.myGroupList(mdto.getId());
		
		String id =mdto.getId();
		String serchtexts = serchtext;		
		
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("id", id);
		map.put("serchtext", serchtexts);
		
		List<MatchDto> list = matchService.soloSerch(map);
		
	 
		model.addAttribute("matchlist", list);	
		model.addAttribute("myGroupList", myGroupLists);
		
		return "/match/matchList";
	}
	 
	// 그룹리스트(inviteGroupList)
	
	@RequestMapping(value="/inviteGroupList",method = {RequestMethod.GET, RequestMethod.POST})
	public String inviteGroup(Model model, HttpServletRequest request,String serchtext) {
					
		// 세션 아이디값 얻어오기
		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		String id =	mdto.getId();	
		
		List<GroupDto> list = myGroupService.myGroupList(id);		
		model.addAttribute("mygrouplist",list);		
		return "/match/inviteGroup";
	}
	
	

	// 그룹인원 중복검사
	@RequestMapping(value="/inviteCheck", produces = "application/text; charset=utf8",method = {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public String inviteCheck(Model model, int gseq, HttpSession session, @RequestParam String id){
		//MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		List<String> list = matchService.inviteCheck(gseq);
		
		System.out.println(gseq);
		System.out.println(id);
		
		
		for(int i =0; i<list.size(); i ++) {
			System.out.println(list.get(i));
			if(id.equals(list.get(i))) {
				System.out.println(list.get(i));
				String msg = "이미 가입된 그룹입니다.";
				return msg;
			}
		}
		
		return "";
	}
	
	
	//그룹초대(inviteGroup)
	@RequestMapping(value="/inviteGroup", produces = "application/text; charset=utf8",method = {RequestMethod.GET, RequestMethod.POST})
	public String inviteGroup(Model model, HttpServletRequest request,String id, int selGroup){
		
		// 세션 아이디값 얻어오기
		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		String sendid =	mdto.getId();
		GroupDto dto = matchService.matchGroupQseq(selGroup);
		
		// 중복 메세지 신청 체크
		Map<String,String> sendMsgchk = new HashMap<String,String>();
		sendMsgchk.put("gseq", String.valueOf(dto.getGseq()));
		sendMsgchk.put("id", sendid);		
		int chkmsg = matchService.sendMsgcheck(sendMsgchk);
		
		if(chkmsg >0){
	
		Map<String,String> map = new HashMap<String,String>();
		map.put("gseq", String.valueOf(dto.getGseq()));
		map.put("id", id);
		map.put("separation", "그룹초대");
		map.put("sendid", sendid);
		map.put("country", dto.getCountry());
		map.put("city", dto.getCity());
		map.put("sdate", dto.getSdate());
		map.put("ldate", dto.getLdate());
		
			

		
		int res = matchService.inviteGroup(map);
		
		if(res > 0) {
		return "common/PopupClose";
	
	}
	   }else{
		   return "common/PopupClose";
	   }
			//에러페이지로 이동
		return "";
	}
	
	//그룹 신청(groupMatch)
	
	@RequestMapping(value = "/groupMatch", method = { RequestMethod.GET, RequestMethod.POST })
	public String groupMatch(Model model, HttpServletRequest request, int gseq) {
		
		// 세션 아이디값 얻어오기
			HttpSession session = request.getSession();
			MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
			
		String sendid =	mdto.getId();		
		GroupDto dto = matchService.matchGroupQseq(gseq);
		
		//  중복 메세지 신청 체크
		Map<String,String> sendMsgchk = new HashMap<String,String>();
		sendMsgchk.put("gseq", String.valueOf(dto.getGseq()));
		sendMsgchk.put("id", sendid);		
		int chkmsg = matchService.sendMsgcheck(sendMsgchk);
		
		if(chkmsg >0){
		
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("gseq", String.valueOf(dto.getGseq()));
		map.put("separation", "그룹신청");
		map.put("sendid", sendid);
		map.put("country", dto.getCountry());
		map.put("city", dto.getCity());
		map.put("sdate", dto.getSdate());
		map.put("ldate", dto.getLdate());
		
		int res = matchService.groupMatch(map);
		
		if(res > 0) {
			return "redirect:matchList.do";
		}
		
	  }else{
		  return "redirect:matchList.do";
	  }
		// 에러페이지로 이동
		return "";
	}
	
	

	@RequestMapping(value = "/tourDiary", method = { RequestMethod.GET, RequestMethod.POST })
	public String tourDiary(Model model, HttpServletRequest request, int pageNum) {

		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");

		List<String> list = tourDiaryService.insertIdList(mdto.getId());
		int res = 0;
		for (int i = 0; i < list.size(); i++) {
			res = tourDiaryService.insertDiary(list.get(i));
		}
		
		if (res > 0) {
			res = tourDiaryService.dataMove();
		}
		
		List<TourDiaryDto> countryLists = tourDiaryService.tourDiaryList(mdto.getId(),pageNum);
		int dcnt = tourDiaryService.diaryCnt(mdto.getId());

		Map<Integer, List<TourDiaryDto>> contentMap = new HashMap<>();

		for (int i = 0; i < countryLists.size(); i++) {
			contentMap.put(i, tourDiaryService.getTourContent(countryLists.get(i)));
		}

		model.addAttribute("countryList", countryLists);
		model.addAttribute("contentMap", contentMap);
		model.addAttribute("dcnt", dcnt);

		return "/match/tourDiary";
	}

	@RequestMapping(value = "/delDiary", method = { RequestMethod.GET, RequestMethod.POST })
	public String delTourDiary(Model model, TourDiaryDto tourDiaryDto, HttpServletRequest request) {

		int res = tourDiaryService.delDiary(tourDiaryDto);
		HttpSession session = request.getSession();
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		int dcnt = tourDiaryService.diaryCnt(mdto.getId());

		List<TourDiaryDto> countryLists = tourDiaryService.tourDiaryList(mdto.getId(),1);

		Map<Integer, List<TourDiaryDto>> contentMap = new HashMap<>();

		for (int i = 0; i < countryLists.size(); i++) {
			contentMap.put(i, tourDiaryService.getTourContent(countryLists.get(i)));
		}

		model.addAttribute("countryList", countryLists);
		model.addAttribute("contentMap", contentMap);
		model.addAttribute("dcnt", dcnt);
		return "/match/tourDiary";
	}

	@RequestMapping(value = "/messageBox", method = { RequestMethod.GET, RequestMethod.POST })
	public String messageBox(Model model, HttpSession session, int pageNum) {
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");

		List<MessageBoxDto> lists = messageBoxService.messageList(mdto.getId(), pageNum);
		int msgCnt = messageBoxService.getMessageCnt(mdto.getId());
		model.addAttribute("msgCnt",msgCnt);
		model.addAttribute("list", lists);

		return "/match/receiveMessage";
	}

	@RequestMapping(value = "/accept", method = { RequestMethod.GET, RequestMethod.POST })
	public String accept(Model model, int mseq, HttpSession session, int invite_group, String separation, 
			String send_id) {
		MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
		if (separation.equals("그룹초대")) {
			int res = messageBoxService.inviteMessageAccept(mdto.getId(), invite_group);
			if (res > 0) {
				res = messageBoxService.messageRejection(mseq);
				if (res > 0) {
					List<MessageBoxDto> lists = messageBoxService.messageList(mdto.getId(), 1);
					int msgCnt = messageBoxService.getMessageCnt(mdto.getId());
					model.addAttribute("msgCnt",msgCnt);
					model.addAttribute("list", lists);
				}
			}
		} else if (separation.equals("그룹신청")) {
			int res = messageBoxService.requestMessageAccept(send_id, invite_group);
			if(res > 0) {
				res = messageBoxService.messageRejection(mseq);
				if(res > 0) {
					List<MessageBoxDto> lists = messageBoxService.messageList(mdto.getId(), 1);
					int msgCnt = messageBoxService.getMessageCnt(mdto.getId());
					model.addAttribute("msgCnt",msgCnt);
					model.addAttribute("list", lists);
				}
			}
		}

		return "/match/receiveMessage";
	}

	@RequestMapping(value = "/rejection", method = { RequestMethod.GET, RequestMethod.POST })
	public String rejection(Model model, int mseq, HttpSession session) {
		int res = messageBoxService.messageRejection(mseq);

		if (res > 0) {
			MemberDto mdto = (MemberDto) session.getAttribute("loginPerson");
			List<MessageBoxDto> lists = messageBoxService.messageList(mdto.getId(), 1);
			int msgCnt = messageBoxService.getMessageCnt(mdto.getId());
			model.addAttribute("msgCnt",msgCnt);
			model.addAttribute("list", lists);
		}

		return "/match/receiveMessage";
	}
	
}
