package com.hk.tourmate.login.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.tourmate.login.dto.CustomerDto;

@Repository
public class CustomerDaoImpl implements CustomerDao {

//	@Autowired
//	private SqlSessionTemplate sqlSession;
//	
//	@Override
//	public List<CustomerDto> selectAll() {
//		// TODO Auto-generated method stub
//		
//		List<CustomerDto> lists = new ArrayList<>();
//		
//		lists = sqlSession.selectList("customer.selectCustomer");
//		
//		return lists;
//	}

}
