package com.hk.tourmate.login.model.dao;

import java.util.Map;

import com.hk.tourmate.login.dto.MemberDto;

public interface MemberDao {

	public int insertMember(MemberDto mdto);
	public MemberDto loginChk(Map<String, String> map);
	public String checkId(String id);
	public MemberDto myInfo(String id);
	public int deleteInfo(String id);
	public int updateInfo(MemberDto mdto);
}
