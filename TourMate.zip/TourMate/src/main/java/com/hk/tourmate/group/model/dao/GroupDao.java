package com.hk.tourmate.group.model.dao;

import java.util.List;
import java.util.Map;

import com.hk.tourmate.group.dto.GroupDto;

public interface GroupDao {
	
	public int insertGroup(GroupDto gdto);
	public GroupDto groupJoin(int gseq);
	public int updateGroup(GroupDto gdto);
	public int leavegroup(String id, int gseq);
	public int changeLeader(String id, int gseq);
	public int delGroup(int gseq);
	public int scheduleCount(Map<String, String> map);
	public List<String> myGroupMember(int gseq);
	public int changeSchedule(GroupDto gdto);
}
