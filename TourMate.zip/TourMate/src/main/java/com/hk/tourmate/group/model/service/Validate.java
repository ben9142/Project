package com.hk.tourmate.group.model.service;

import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.hk.tourmate.group.dto.RecommendationDto;

@Service("fileValidator")
public class Validate implements Validator {

	private String jspPath;
	
	public void setJspPath(String jspPath) {
		this.jspPath = jspPath;
	}

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object uploadFile, Errors errors) {
		RecommendationDto file = (RecommendationDto)uploadFile;
		
		if(file.getFile().getSize() == 0) {
			errors.rejectValue("file", "admin/"+jspPath, "Please select a file");
		}
		if(file.getFile().getSize() > 2000000) {
			errors.rejectValue("file", "admin/"+jspPath, "byte size over !!");
		}

	}
}
