package com.hk.tourmate.login.dto;

import org.springframework.web.multipart.MultipartFile;

public class MemberDto {

	String id;
	String password;
	String gender;
	String name;
	String address;
	String phone;
	String email;
	String birth;
	String img;
	String role;
	String enabled;
	MultipartFile imgFile;
	
	public MemberDto() {
		// TODO Auto-generated constructor stub
	}
	
	public MemberDto(String id, String password, String gender, String name, String address, String phone, String email,
			String birth, String img, String role, String enabled) {
		super();
		this.id = id;
		this.password = password;
		this.gender = gender;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.birth = birth;
		this.img = img;
		this.role = role;
		this.enabled = enabled;
	}
	

	public MemberDto(String id, String password, String address, String phone, String email, String img,
			MultipartFile imgFile) {
		super();
		this.id = id;
		this.password = password;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.img = img;
		this.imgFile = imgFile;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	
	public MultipartFile getImgFile() {
		return imgFile;
	}

	public void setImgFile(MultipartFile imgFile) {
		this.imgFile = imgFile;
	}

	@Override
	public String toString() {
		return "MemberDto [id=" + id + ", password=" + password + ", gender=" + gender + ", name=" + name + ", address="
				+ address + ", phone=" + phone + ", email=" + email + ", birth=" + birth + ", img=" + img + ", role="
				+ role + ", enabled=" + enabled + "]";
	}
}
